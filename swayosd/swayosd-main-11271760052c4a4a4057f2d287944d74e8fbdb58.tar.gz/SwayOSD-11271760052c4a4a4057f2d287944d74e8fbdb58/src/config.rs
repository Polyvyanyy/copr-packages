#![allow(dead_code)]

pub const DBUS_PATH: &str = "/org/erikreider/swayosd";
pub const DBUS_BACKEND_NAME: &str = "org.erikreider.swayosd";
pub const DBUS_SERVER_NAME: &str = "org.erikreider.swayosd-server";

pub const APPLICATION_NAME: &str = "org.erikreider.swayosd";
